package com.example.guardiannewsonline;



public class NewsData {
    private String title;
    private String sectionName;
    private String author;
    private String webPublicationDate;
    private String webUrl;

    public NewsData(String title, String sectionName, String author, String webPublicationDate, String webUrl) {
        this.title = title;
        this.sectionName = sectionName;
        this.author = author;
        this.webPublicationDate = webPublicationDate;
        this.webUrl = webUrl;
    }
    public String getTitle() {
        return title;
    }
    public String getSectionName() {
        return sectionName;
    }
    public String getAuthor() {
        return author;
    }
    public String getWebPublicationDate() {
        return webPublicationDate;
    }
    public String getWebUrl() {
        return webUrl;
    }
}


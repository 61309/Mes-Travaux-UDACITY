package com.example.microfinance;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

/**
 * Created by Jean Tide MATONDO MUANDA on 21-03-18.
 * this application consists in presenting to the user the concept of microfinance.
 a series of questions is asked to know if he knows microfinance.
 at the end, the user can consult the correct answers. The program gives
 him the score, on the questions put to him.  He can also if he want, share this
 study with his friends or his family on social networks. If he's really interested, he
 can read the information on the internet about microfinance.
 this app is in french.
 */

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the content of the activity to use the activity_main.xml layout file
        setContentView(R.layout.activity_main);
        // Set a click button on that View
        Button btn = (Button) findViewById(R.id.start);
        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                start();
            }
        });
    }
    public void start() {
        // Create a new intent to open the {@link QuizActivity}
        Intent myIntent = new Intent(MainActivity.this, QuizActivity.class);
        // Start the new activity
        startActivity(myIntent);
    }
}
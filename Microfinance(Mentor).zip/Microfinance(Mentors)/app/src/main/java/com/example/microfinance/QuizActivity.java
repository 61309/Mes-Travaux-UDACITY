package com.example.microfinance;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.content.Intent;
import android.widget.RadioGroup;
import android.widget.Toast;

public class QuizActivity extends AppCompatActivity  {
        int score=0;
        RadioButton an1;
        RadioButton an2;
        RadioGroup quest1;
        RadioGroup quest2;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            // Set the content of the activity to use the QuizActivity.xml layout file
            setContentView(R.layout.quiz);
            // Set a click button on that View
            Button btn2 = (Button) findViewById(R.id.move_button);
            btn2.setOnClickListener( new View.OnClickListener(){
                public void onClick (View v){
                    move(v);
                }
            });
            // get references on the components
            an1 = findViewById(R.id.b1_radio_button);
            an2 = findViewById(R.id.b2_radio_button);
            quest1 = findViewById(R.id.quest1);
            quest2 = findViewById(R.id.quest2);
        }
        // if we click on the radio button, true to false, we give a score
        public void next(){
            if (an1.isChecked()){score++;}
            if (an2.isChecked()){score++;}
            // Create a new intent to open the {@link Quiz2Activity}
            Intent myIntent2 = new Intent(QuizActivity.this, Quiz2Activity.class);
            myIntent2.putExtra("score", score);
            // Start the new activity
            startActivity(myIntent2);
        }
        // if you do not click on the radio button, a message informs you to answer all the questions before continuing
        public void move(View v){
            if (quest1.getCheckedRadioButtonId() == -1 || quest2.getCheckedRadioButtonId() == -1) {
            Toast.makeText(this, R.string.ans, Toast.LENGTH_LONG).show();
            } else
            {next();
            finish();}
        }
}
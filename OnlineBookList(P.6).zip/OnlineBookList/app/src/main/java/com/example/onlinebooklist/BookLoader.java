package com.example.onlinebooklist;

import android.content.AsyncTaskLoader;
import android.content.Context;
import java.util.List;

/**
 * Created by JeanTide on 29-05-18.
 */

public class BookLoader extends AsyncTaskLoader<List<Book>> {
    private String query;
    BookLoader(Context context, String query) {
        super(context);
        this.query = query;
    }

    @Override
    protected void onStartLoading() {
        forceLoad();
    }

    @Override
    public List<Book> loadInBackground() {
        if (query == null) {
            return null;
        }
        String jsonResponse = HttpHandler.fetchBookData(query);
        List<Book> bookList = QueryUtils.extractBooks(jsonResponse);
        return bookList;
    }
}
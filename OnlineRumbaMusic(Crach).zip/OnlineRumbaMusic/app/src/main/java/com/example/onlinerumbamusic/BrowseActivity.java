package com.example.onlinerumbamusic;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;



public class BrowseActivity extends AppCompatActivity {

    private ArrayList<SongVM> listedSongs = new ArrayList<>();
    private Button homeButton;
    private Button nowPlayingButton;
    private Activity currentActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browse);
        currentActivity = this;

        homeButton = (Button) findViewById(R.id.homeButton);
        nowPlayingButton = (Button) findViewById(R.id.nowPlayingButton);
        final Intent i = new Intent(getBaseContext(), MainActivity.class);
        final Intent i2 = new Intent(getBaseContext(), NowPlayingActivity.class);

        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(currentActivity, i);
            }
        });

        nowPlayingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(currentActivity, i2);
            }
        });

        listedSongs.add(new SongVM("Rochereau", "Dialogue", "4:22", "Rumba"));
        listedSongs.add(new SongVM("King Kester", "Nzinzi", "3:02", "RumbaRock"));
        listedSongs.add(new SongVM("Robert Johnson", "Bluesman", "3:20", "Rock"));
        listedSongs.add(new SongVM("Shungu Wembadio", "Maria Valence", "1:42", "Rumba"));
        listedSongs.add(new SongVM("Frank Emilio Flynn", "En Mihabana", "2:42", "Salsa"));
        listedSongs.add(new SongVM("Andrés F.O", "La Vida", "4:31", "Salsa"));
        listedSongs.add(new SongVM("Koffi Olomide", "Coucou", "3:22", "Rumba"));
        listedSongs.add(new SongVM("Marisol Palomo", "Palabras Darei", "2:07", "Flameco"));

        SongAdapter listedSongsAdapter = new SongAdapter(this, android.R.layout.simple_list_item_1, listedSongs);
        listedSongsAdapter.addAll(listedSongs);
        ListView songsListView = (ListView) findViewById(R.id.listedSongListView);
        songsListView.setAdapter(listedSongsAdapter);

    }

    public static void startActivity(Activity currentActivity, Intent intent) {
        currentActivity.startActivity(intent);
        currentActivity.overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }
}


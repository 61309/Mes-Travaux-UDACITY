package com.example.onlinerumbamusic;

import android.content.Context;
import android.support.annotation.IdRes;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;


public class SongAdapter extends ArrayAdapter<SongVM> {
    public SongAdapter(@NonNull Context context, @LayoutRes int resource) {
        super(context, resource);
    }

    public SongAdapter(@NonNull Context context, @LayoutRes int resource, @IdRes int textViewResourceId) {
        super(context, resource, textViewResourceId);
    }

    public SongAdapter(@NonNull Context context, @LayoutRes int resource, @NonNull SongVM[] objects) {
        super(context, resource, objects);
    }

    public SongAdapter(@NonNull Context context, @LayoutRes int resource, @IdRes int textViewResourceId, @NonNull SongVM[] objects) {
        super(context, resource, textViewResourceId, objects);
    }

    public SongAdapter(@NonNull Context context, @LayoutRes int resource, @NonNull List<SongVM> objects) {
        super(context, resource, objects);
    }

    public SongAdapter(@NonNull Context context, @LayoutRes int resource, @IdRes int textViewResourceId, @NonNull List<SongVM> objects) {
        super(context, resource, textViewResourceId, objects);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.song_item_view, parent, false);
        }

        SongVM currentSong = getItem(position);
        TextView artistNameView = (TextView) listItemView.findViewById(R.id.artistNameView);
        artistNameView.setText(currentSong.getArtistName());
        TextView songTitleView = (TextView) listItemView.findViewById(R.id.songTitleView);
        songTitleView.setText(currentSong.getTrackTitle());
        TextView songLenthView = (TextView) listItemView.findViewById(R.id.songLengthView);
        songLenthView.setText(currentSong.getTrackLength());
        return listItemView;
    }
}


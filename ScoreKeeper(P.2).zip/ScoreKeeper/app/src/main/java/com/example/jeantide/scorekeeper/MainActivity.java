package com.example.jeantide.scorekeeper;

/**
 * This app gives a user the possibility to track the score of two different teams.
 * Team A and Team B.
 */

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    //Tracks the score for Team A
    private int scoreTeamA = 0;
   // Tracks the score for Team B
    private int scoreTeamB = 0;

    private TextView scoreViewTeamA;
    private TextView scoreViewTeamB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //layout file assignment
        setContentView(R.layout.activity_main);

        //obtain references on the components
        scoreViewTeamA = findViewById(R.id.team_a_score);
        scoreViewTeamB = findViewById(R.id.team_b_score);
    }

    /**
     * Displays the given score for Team A :
     *
     * touchdown = button (+4)points
     * fieldGoal = button (+3)points
     * extraTwo = button (+2)points
     * extraOne = button FOUL(+1)
     * safety = button KEEPER(+6)
     *
     */

    public void displayScoreTeamA(int score) {
        scoreViewTeamA.setText(String.valueOf(score));
    }

    /**
     * Increase the score for Team A by 4 points.
     */

    public void touchdownTeamA(View view) {
        scoreTeamA += 4;
        displayScoreTeamA(scoreTeamA);
    }

    /**
     * Increase the score for Team A by 3 points.
     */

    public void fieldGoalTeamA(View view) {
        scoreTeamA += 3;
        displayScoreTeamA(scoreTeamA);
    }

    /**
     * Increase the score for Team A by 2 points.
     */

    public void extraTwoTeamA(View view) {
        scoreTeamA += 2;
        displayScoreTeamA(scoreTeamA);
    }

    /**
     * Increase the score for Team A by 1 point.
     */

    public void extraOneTeamA(View view) {
        scoreTeamA += 1;
        displayScoreTeamA(scoreTeamA);
    }

    /**
     *
     Increase the score for Team A by 6 points.
     */

    public void safetyTeamA(View view) {
        scoreTeamA += 6;
        displayScoreTeamA(scoreTeamA);
    }

    /**
     * Displays the given score for Team B :
     *
     * touchdown = button (+4)points
     * fieldGoal = button (+3)points
     * extraTwo = button (+2)points
     * extraOne = button FOUL(+1)
     * safety = button KEEPER(+6)
     *
     */

    public void displayScoreTeamB(int score) {
        scoreViewTeamB.setText(String.valueOf(score));
    }

    /**
     *
     Increase the score for Team B by 4 points.
     */

    public void touchdownTeamB(View view) {
        scoreTeamB += 4;
        displayScoreTeamB(scoreTeamB);
    }

    /**
     *
     Increase the score for Team B by 3 points.
     */

    public void fieldGoalTeamB(View view) {
        scoreTeamB += 3;
        displayScoreTeamB(scoreTeamB);
    }

    /**
     *
     Increase the score for Team B by 2 points.
     */

    public void extraTwoTeamB(View view) {
        scoreTeamB += 2;
        displayScoreTeamB(scoreTeamB);
    }

    /**
     *
     Increase the score for Team B by 1 point.
     */

    public void extraOneTeamB(View view) {
        scoreTeamB += 1;
        displayScoreTeamB(scoreTeamB);
    }

    /**
     *
     Increase the score for Team B by 6 points.
     */

    public void safetyTeamB(View view) {
        scoreTeamB += 6;
        displayScoreTeamB(scoreTeamB);
    }

    /**
     * resetScore = button rest:
     * initialValue = 0
     * Delete all Team A and Team B scores on the screen and display 0.
     *
     */

    public void resetScore(View view) {
        scoreTeamA = scoreTeamB = 0;
        displayScoreTeamA(scoreTeamA);
        displayScoreTeamB(scoreTeamB);
    }
}

package com.example.tourguideapp;

/**
 * Created by JeanTide on 01-05-18.
 */

public interface ListItem {

    String getName();
    String getDetails();
    String getPriceRange();
    String getOpeningTime();
    int getPhoto();
    String getStarCount();
}


package com.example.tourguideapp;

import android.content.Intent;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    ListItemFragment listItemFragment;

    ArrayList<ListItem> sightList = new ArrayList<>();
    ArrayList<ListItem> cafeList = new ArrayList<>();
    ArrayList<ListItem> restaurantList = new ArrayList<>();
    ArrayList<ListItem> hotelList = new ArrayList<>();

    private String cheapest;
    private String cheap;
    private String moderate;
    private String expensive;
    private String twoStar;
    private String threeStar;
    private String fourStar;
    private String fiveStar;

    FragmentManager fragmentManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        cheapest = getString(R.string.cheapest);
        cheap = getString(R.string.cheap);
        moderate = getString(R.string.moderate);
        expensive = getString(R.string.expensive);
        twoStar = getString(R.string.twoStars);
        threeStar = getString(R.string.threeStars);
        fourStar = getString(R.string.fourStars);
        fiveStar = getString(R.string.fiveStars);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fillCafeList();
        fillRestaurantList();
        fillSightList();
        fillHotelList();
        fragmentManager = getSupportFragmentManager();
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.nav_sights:
                openListItemFragment(sightList, getString(R.string.sights));
                break;
            case R.id.nav_cafes:
                openListItemFragment(cafeList, getString(R.string.cafés));
                break;
            case R.id.nav_restaurants:
                openListItemFragment(restaurantList, getString(R.string.restaurants));
                break;
            case R.id.nav_hotels:
                openListItemFragment(hotelList, getString(R.string.hotels));
                break;
            case R.id.nav_share:
                Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                sharingIntent.setType(getString(R.string.text_plain));
                startActivity(Intent.createChooser(sharingIntent, getString(R.string.share_via)));
                break;
            case R.id.nav_send:
                Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
                emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, getString(R.string.welcome_lg));
                emailIntent.setType(getString(R.string.plain_text));
                startActivity(Intent.createChooser(emailIntent, getString(R.string.send_email)));
                break;
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void fillCafeList() {
        cafeList.add(new CafeVM(getString(R.string.pot_name), getString(R.string.pot_details), getString(R.string.open_times_9_21), moderate));
        cafeList.add(new CafeVM(getString(R.string.bolas_name), getString(R.string.bolas_details), getString(R.string.open_times_9_21), cheap));
        cafeList.add(new CafeVM(getString(R.string.verre_name), getString(R.string.verre_details), getString(R.string.open_times_9_21), moderate));
        cafeList.add(new CafeVM(getString(R.string.diode_name), getString(R.string.diode_details), getString(R.string.open_times_9_21), moderate));
        cafeList.add(new CafeVM(getString(R.string.peke_name), getString(R.string.peke_details), getString(R.string.open_times_9_21), expensive));
        cafeList.add(new CafeVM(getString(R.string.escalier_name), getString(R.string.escalier_details), getString(R.string.open_times_9_21), cheapest));
    }

    public void fillRestaurantList() {
        restaurantList.add(new RestaurantVM(getString(R.string.juliette_name), getString(R.string.juliette_details), getString(R.string.open_times_9_21), expensive));
        restaurantList.add(new RestaurantVM(getString(R.string.rive_name), getString(R.string.rive_details), getString(R.string.open_times_9_21), moderate));
        restaurantList.add(new RestaurantVM(getString(R.string.aubergine_name), getString(R.string.aubergine_details), getString(R.string.open_times_9_21), expensive));
        restaurantList.add(new RestaurantVM(getString(R.string.marelle_name), getString(R.string.marelle_details), getString(R.string.open_times_9_21), expensive));
        restaurantList.add(new RestaurantVM(getString(R.string.shangri_name), getString(R.string.shangri_details), getString(R.string.open_times_9_21), expensive));
        restaurantList.add(new RestaurantVM(getString(R.string.oreades_name), getString(R.string.oreades_details), getString(R.string.open_times_9_21), expensive));
        restaurantList.add(new RestaurantVM(getString(R.string.roches_name), getString(R.string.roches_details), getString(R.string.open_times_9_21), expensive));
    }

    public void fillSightList() {
        sightList.add(new SightVM(getString(R.string.great_name), getString(R.string.great_details), R.drawable.great));
        sightList.add(new SightVM(getString(R.string.church_name), getString(R.string.church_details), R.drawable.smallchurch));
        sightList.add(new SightVM(getString(R.string.parc_name), getString(R.string.parc_details), R.drawable.parc));
        sightList.add(new SightVM(getString(R.string.opera_name), getString(R.string.opera_details), R.drawable.opera));
        sightList.add(new SightVM(getString(R.string.university_name), getString(R.string.univerity_details), R.drawable.university));
    }

    private void fillHotelList() {
        hotelList.add(new HotelVM((getString(R.string.campanille_name)), getString(R.string.campanille_details), twoStar, cheap));
        hotelList.add(new HotelVM((getString(R.string.univers_name)), getString(R.string.univers_details), fiveStar, expensive));
        hotelList.add(new HotelVM((getString(R.string.couronne_name)), getString(R.string.couronne_details), fourStar, moderate));
        hotelList.add(new HotelVM((getString(R.string.plaza_name)), getString(R.string.plaza_details), twoStar, cheap));
        hotelList.add(new HotelVM((getString(R.string.globales_name)), getString(R.string.globales_details), fourStar, moderate));
        hotelList.add(new HotelVM((getString(R.string.ramada_name)), getString(R.string.ramada_details), threeStar, moderate));
    }

    private void openListItemFragment(ArrayList<ListItem> items, String title) {
        listItemFragment = new ListItemFragment(items, title);
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragmentContainer, listItemFragment);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }

}
